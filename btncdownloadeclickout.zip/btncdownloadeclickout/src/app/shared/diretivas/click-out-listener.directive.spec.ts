import { ClickOutListenerDirective } from './click-out-listener.directive';

describe('ClickOutListenerDirective', () => {
  it('should create an instance', () => {
    const directive = new ClickOutListenerDirective(null);
    expect(directive).toBeTruthy();
  });
});
