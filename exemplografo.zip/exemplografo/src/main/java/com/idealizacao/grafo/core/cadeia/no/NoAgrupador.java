package com.idealizacao.grafo.core.cadeia.no;

import com.idealizacao.grafo.core.cadeia.no.No;
import com.idealizacao.grafo.core.cadeia.no.TipoNo;

import java.util.ArrayList;
import java.util.List;

public class NoAgrupador extends No {
    private List<No> filhos;

    public NoAgrupador(int id, String descricao, TipoNo tipo) {
        super(id, descricao, tipo);
        filhos = new ArrayList<>();
    }

    public void addFilhos(List<No> filhos){
        this.filhos.addAll(filhos);
    }

    public List<No> getFilhos() {
        return filhos;
    }
}
