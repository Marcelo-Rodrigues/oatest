package com.idealizacao.grafo.api.service.cadeia;

import com.idealizacao.grafo.api.dao.cadeia.CadeiaDAO;
import com.idealizacao.grafo.api.vo.cadeia.CadeiaProcessadaVO;
import com.idealizacao.grafo.core.cadeia.Cadeia;
import org.springframework.stereotype.Service;

@Service
public class CadeiaService {
    private CadeiaDAO cadeiaDAO;
    public CadeiaService(CadeiaDAO cadeiaDAO) {
        this.cadeiaDAO = cadeiaDAO;
    }

    public CadeiaProcessadaVO consultarCadeia() {
        Cadeia cadeia = new Cadeia(cadeiaDAO.consultarCadeia());
        return cadeia.processar();
    }
}
