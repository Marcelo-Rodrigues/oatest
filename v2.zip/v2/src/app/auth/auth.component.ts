import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'my-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css']
})
export class AuthComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    window.setTimeout(() => {
      window.localStorage.setItem('access_token', 'abc');

      window.setTimeout(() => {
      window.opener.postMessage('loginSuccess', '*');
      window.close();
      }, 500);
    }
      , 4000);
  }

}
