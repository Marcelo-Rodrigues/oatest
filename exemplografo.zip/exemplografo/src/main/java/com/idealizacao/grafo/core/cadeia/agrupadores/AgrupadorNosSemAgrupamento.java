package com.idealizacao.grafo.core.cadeia.agrupadores;

import com.idealizacao.grafo.core.cadeia.no.No;
import com.idealizacao.grafo.core.cadeia.no.NoAgrupador;
import com.idealizacao.grafo.core.cadeia.no.TipoNo;

import java.util.List;

public class AgrupadorNosSemAgrupamento implements AgrupadorNos {
    @Override
    public void agrupar(Agrupamento agrupamento) {
        List<No> nos = agrupamento.getNosNaoProcessados();

        agrupamento.adicionarNosSemGrupo(nos);
    }
}
