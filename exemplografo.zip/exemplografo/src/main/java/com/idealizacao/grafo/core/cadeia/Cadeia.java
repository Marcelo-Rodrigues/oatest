package com.idealizacao.grafo.core.cadeia;

import com.idealizacao.grafo.api.vo.cadeia.CadeiaConsultadaVO;
import com.idealizacao.grafo.api.vo.cadeia.CadeiaProcessadaVO;
import com.idealizacao.grafo.core.cadeia.agrupadores.AgrupadoresNoCadeia;
import com.idealizacao.grafo.core.cadeia.categorizadores.CategorizadoresNoCadeia;
import com.idealizacao.grafo.core.cadeia.no.No;

import java.util.List;

public class Cadeia {
    private CadeiaConsultadaVO cadeiaConsultadaVO;

    public Cadeia(CadeiaConsultadaVO cadeiaConsultadaVO) {
        this.cadeiaConsultadaVO = cadeiaConsultadaVO;
    }

    public CadeiaProcessadaVO processar() {
        CadeiaProcessadaVO cadeia = new CadeiaProcessadaVO(this.cadeiaConsultadaVO.getAncora());
        List<No> nosCategorizados = new CategorizadoresNoCadeia().categorizar(this.cadeiaConsultadaVO.getRelacionados());
        List<No> nosAgrupados = new AgrupadoresNoCadeia().agrupar(nosCategorizados);
        cadeia.addRelacionados(nosAgrupados);
        return cadeia;
    }
}
