package com.idealizacao.grafo.core.cadeia.agrupadores;

public interface AgrupadorNos {
    void agrupar(Agrupamento agrupamento);
}
