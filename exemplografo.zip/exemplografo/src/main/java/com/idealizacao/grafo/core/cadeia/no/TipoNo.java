package com.idealizacao.grafo.core.cadeia.no;

public enum TipoNo {
    PESSOAFISICA,
    INSTITUICAOFINANCEIRA,
    OUTROS;
}
