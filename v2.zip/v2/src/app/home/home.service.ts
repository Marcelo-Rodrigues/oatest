import { Injectable } from '@angular/core';
import { HttpAutenticado } from '../http-autenticado.service';


@Injectable()
export class HomeService {

  constructor(private http: HttpAutenticado) { }

  request() {
    return this.http.get('http://localhost:8080/oatest/urlRoleA')
      .map(res => res.json());
  }

}
