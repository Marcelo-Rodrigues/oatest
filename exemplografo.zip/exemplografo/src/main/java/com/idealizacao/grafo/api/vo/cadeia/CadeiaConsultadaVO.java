package com.idealizacao.grafo.api.vo.cadeia;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class CadeiaConsultadaVO {
    private NoConsultadoVO ancora;
    private List<NoConsultadoVO> relacionados;

    public CadeiaConsultadaVO(NoConsultadoVO ancora) {
        this.ancora = ancora;
        this.relacionados = new ArrayList<>();
    }

    public NoConsultadoVO getAncora() {
        return ancora;
    }

    public List<NoConsultadoVO> getRelacionados() {
        return relacionados;
    }

    public void addRelacionados(Collection<? extends NoConsultadoVO> relacionados) {
        this.relacionados.addAll(relacionados);
    }
}
