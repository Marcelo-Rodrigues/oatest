import { Component, OnInit } from '@angular/core';
import { HomeService } from './home.service';
import { AuthService } from '../auth/auth.service';

@Component({
  selector: 'my-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  usuarios = [];

  constructor(private homeService: HomeService, private auth: AuthService) { }

  ngOnInit() {
    this.homeService.request()
      .subscribe(usr => this.usuarios = usr,
      err => {
        console.log('erro: ' + err);
      });
  }

}
