import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'my-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {

    window.setTimeout(() => {
      window.localStorage.setItem('access_token', 'abc');
      window.opener.postMessage('loginSuccess', '*');
      window.close();
    }
      , 4000);

  }

}
