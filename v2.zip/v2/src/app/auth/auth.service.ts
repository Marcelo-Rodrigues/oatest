import { Injectable, OnInit, HostListener } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';

@Injectable()
export class AuthService {
  public emAutenticacao: boolean;
  private messageLoginSucess: Observable<{}>;

  constructor() {
    this.emAutenticacao = false;
    this.messageLoginSucess = Observable.fromEvent(window, 'message')
      .filter(ev => (<MessageEvent>ev).data === 'loginSuccess')
      .do(() => {
        console.log('eMAuth=false');
        this.emAutenticacao = false;
      });
  }

  public login(observable: Observable<any>): Observable<any> {
    console.log('emAutenticacao' + this.emAutenticacao);
    if (!this.emAutenticacao) {

      this.abrirJanelaOAuth();
    }

    return this.messageLoginSucess.flatMap(() => observable);
  }

  abrirJanelaOAuth() {
    this.emAutenticacao = true;
    window.open('/auth', '_blank', 'height=300px,width=400px,menubar=no,resizable=no,status=no').focus();
  }

}
