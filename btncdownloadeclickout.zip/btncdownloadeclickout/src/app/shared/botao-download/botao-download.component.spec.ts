import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BotaoDownloadComponent } from './botao-download.component';

describe('BotaoDownloadComponent', () => {
  let component: BotaoDownloadComponent;
  let fixture: ComponentFixture<BotaoDownloadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BotaoDownloadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BotaoDownloadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
