import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HomeService } from './home/home.service';
import { AuthComponent } from './auth/auth.component';
import { AppRoutingModule } from './app-routing.module';

import { HttpModule, XHRBackend, RequestOptions } from '@angular/http';
import { HttpAutenticado } from './http-autenticado.service';
import { AuthService } from './auth/auth.service';
import { BComponent } from './b/b.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AuthComponent,
    BComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpModule
  ],
  providers: [AuthService,
    {
      provide: HttpAutenticado,
      useFactory: requestLoader,
      deps: [XHRBackend, RequestOptions, AuthService]
    },
    HomeService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

export function requestLoader(backend: XHRBackend, options: RequestOptions, authService: AuthService) {
  return new HttpAutenticado(backend, options, authService);
}
