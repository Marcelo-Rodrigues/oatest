package com.idealizacao.grafo.core.cadeia.categorizadores;

import com.idealizacao.grafo.api.vo.cadeia.NoConsultadoVO;
import com.idealizacao.grafo.core.cadeia.no.No;

import java.util.List;
import java.util.stream.Collectors;

public class CategorizadoresNoCadeia {

    private CategorizadorNo categorizadorEncadeado;

    public CategorizadoresNoCadeia() {
        categorizadorEncadeado = new CategorizadorNoIF();
        categorizadorEncadeado.setProximoCategorizador(new CategorizadorNoPadrao());
    }

    public List<No> categorizar(List<NoConsultadoVO> noConsultado){
        return noConsultado.stream()
                .map(no-> categorizadorEncadeado.categorizar(no))
                .collect(Collectors.toList());
    }
}
