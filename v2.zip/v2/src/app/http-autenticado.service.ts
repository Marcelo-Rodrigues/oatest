import { Injectable, HostListener } from '@angular/core';
import { Http, Request, Response, ConnectionBackend, RequestOptions, RequestOptionsArgs } from '@angular/http';
import { AuthService } from './auth/auth.service';
import { Observable } from 'rxjs/Observable';


import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/fromEvent';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/mapTo';
import 'rxjs/add/operator/share';
import 'rxjs/add/operator/mergeMap';

@Injectable()
export class HttpAutenticado extends Http {

  constructor(_backend: ConnectionBackend, _defaultOptions: RequestOptions, private authService: AuthService) {
    super(_backend, _defaultOptions);
  }

  request(url: string | Request, options?: RequestOptionsArgs): Observable<Response> {

    return super.request(url, this.addAuthHeader(url, options)).catch(res => {
      if (res.status === 401) {
        console.log('401');
        return this.retry(url, options);
      }

      return Observable.throw(res);
    });
  }

  addAuthHeader(url: string | Request, options?: RequestOptionsArgs) {
    const token = localStorage.getItem('access_token');

    if (typeof url === 'string') { // meaning we have to add the token to the options, not in url
      if (!options) {
        options = <any>{ headers: new Headers() };
      }
      options.headers.set('Authorization', `Bearer ${token}`);
      console.log('options:' + JSON.stringify(options));
    } else {
      // we have to add the token to the url object
      url.headers.set('Authorization', `Bearer ${token}`);
      console.log('headers:' + JSON.stringify(url.headers));
    }

    return options;
  }


  retry(url, options): Observable<Response> {
    return this.authService.login(this.request(url, this.addAuthHeader(url, options)));
  }
}
