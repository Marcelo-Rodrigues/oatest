import { Component, OnInit, Input, ElementRef, ViewChild } from '@angular/core';
import { RequestOptions, ResponseContentType } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/operator/map';

@Component({
  selector: 'my-botao-download',
  templateUrl: './botao-download.component.html',
  styleUrls: ['./botao-download.component.css']
})
export class BotaoDownloadComponent implements OnInit {
  @Input() executorServico: Function;
  @Input() nomeArquivo: string;
  isDownloading = false;

  reqOpt: RequestOptions;
  @ViewChild('hiddenDownloader') hiddenDownloaderRef: ElementRef;

  constructor() {
    this.reqOpt = new RequestOptions({
      responseType: ResponseContentType.Blob
    });
  }

  ngOnInit() { }

  salvar(url: string) {
    (<HTMLAnchorElement>this.hiddenDownloaderRef.nativeElement).href = url;
    (<HTMLAnchorElement>this.hiddenDownloaderRef.nativeElement).click();
  }

  download() {
    this.isDownloading = true;

    (<Observable<Response>>this.executorServico(this.reqOpt))
      .subscribe(
      res => {
        const url = URL.createObjectURL(res.blob(), <ObjectURLOptions>{ oneTimeOnly: true });
        this.salvar(url);
        this.isDownloading = false;
      },
      err => {
        this.isDownloading = false;
        Observable.throw(err);
      }
      );
  }
}
