import { Injectable, HostListener } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Http, Request, Response, ConnectionBackend, RequestOptions, RequestOptionsArgs } from '@angular/http';

import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/fromEvent';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/mapTo';
import 'rxjs/add/operator/share';
import 'rxjs/add/operator/mergeMap';

@Injectable()
export class HttpAutenticado extends Http {

  constructor(_backend: ConnectionBackend, _defaultOptions: RequestOptions) {
    super(_backend, _defaultOptions);
  }

  request(url: string | Request, options?: RequestOptionsArgs): Observable<Response> {
    const token = localStorage.getItem('access_token');

    if (typeof url === 'string') { // meaning we have to add the token to the options, not in url
      if (!options) {
        options = <any>{ headers: new Headers() };
      }
      options.headers.set('Authorization', `Bearer ${token}`);
    } else {
      // we have to add the token to the url object
      url.headers.set('Authorization', `Bearer ${token}`);
    }
    return super.request(url, options).catch(res => {
      if (res.status === 401) {
        return this.retry(url, options);
      }

      return Observable.throw(res);
    });
  }


  retry(url, options): Observable<Response> {
    window.open('/login');
    return Observable
      .fromEvent(window, 'message')
      .filter(ev => (<MessageEvent>ev).data === 'loginSuccess')
      .flatMap(item => this.request(url, options));
  }
}
