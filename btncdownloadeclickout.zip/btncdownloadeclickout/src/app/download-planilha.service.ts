import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class DownloadPlanilhaService {

  constructor(private http: Http) { }

  downloadTemplate(reqOpt) {
    return this.http.get('http://127.0.0.1:8080/template-planilha.xlsx', reqOpt);
  }

  downloadPlanilha(reqOpt) {
    return this.http.get('http://127.0.0.1:8080/planilha.xlsx', reqOpt);
  }
}
