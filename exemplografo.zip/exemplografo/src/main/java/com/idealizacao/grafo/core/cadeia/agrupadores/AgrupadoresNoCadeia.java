package com.idealizacao.grafo.core.cadeia.agrupadores;

import com.idealizacao.grafo.api.vo.cadeia.NoConsultadoVO;
import com.idealizacao.grafo.core.cadeia.no.No;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class AgrupadoresNoCadeia {
    private List<AgrupadorNos> agrupadoresNos;

    public AgrupadoresNoCadeia() {
        this.agrupadoresNos = Arrays.asList(new AgrupadorNosIF(), new AgrupadorNosSemAgrupamento());
    }

    public List<No> agrupar(List<No> nos){
        Agrupamento agrupamento = new Agrupamento(nos);
        agrupadoresNos.stream().forEach(agrupador->agrupador.agrupar(agrupamento));

        return agrupamento.getNosProcessados();
    }
}
