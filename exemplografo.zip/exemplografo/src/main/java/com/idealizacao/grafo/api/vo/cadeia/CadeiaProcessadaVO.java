package com.idealizacao.grafo.api.vo.cadeia;

import com.idealizacao.grafo.core.cadeia.no.No;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class CadeiaProcessadaVO {
    private NoConsultadoVO ancora;
    private List<No> relacionados;

    public CadeiaProcessadaVO(NoConsultadoVO ancora) {
        this.ancora = ancora;
        this.relacionados = new ArrayList<>();
    }

    public NoConsultadoVO getAncora() {
        return ancora;
    }

    public List<No> getRelacionados() {
        return relacionados;
    }

    public void addRelacionados(Collection<? extends No> relacionados) {
        this.relacionados.addAll(relacionados);
    }
}
