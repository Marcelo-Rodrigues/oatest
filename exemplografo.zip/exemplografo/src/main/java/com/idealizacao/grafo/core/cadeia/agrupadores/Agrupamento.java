package com.idealizacao.grafo.core.cadeia.agrupadores;

import com.idealizacao.grafo.core.cadeia.no.No;
import com.idealizacao.grafo.core.cadeia.no.NoAgrupador;
import com.idealizacao.grafo.core.cadeia.no.TipoNo;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Agrupamento {
    private List<No> nosNaoProcessados;
    private List<No> nosProcessados;

    public  Agrupamento(List<No> nosNaoAgrupados){
        this.nosNaoProcessados = nosNaoAgrupados;
        this.nosProcessados = new ArrayList<>();
    }

    public void agrupar(NoAgrupador noAgrupador) {
        nosProcessados.add(noAgrupador);
        nosNaoProcessados.removeAll(noAgrupador.getFilhos());
    }

    public void adicionarNosSemGrupo(List<No> nos) {
        nosProcessados.addAll(nos);
        nosNaoProcessados.removeAll(nos);
    }

    public List<No> getNosNaoProcessados() {
        return nosNaoProcessados;
    }

    public List<No> getNosNaoProcessados(TipoNo tipoNo) {
        return agruparNosPorTipo(nosNaoProcessados, tipoNo);
    }

    public List<No> getNosProcessados() {
        return nosProcessados;
    }

    public List<No> getNosProcessados(TipoNo tipoNo) {
        return agruparNosPorTipo(nosProcessados, tipoNo);
    }

    private <T extends No> List<T> agruparNosPorTipo(List<T> nos, TipoNo tipoNo) {
        return nos.stream()
                .filter(no -> no.getTipo() == tipoNo)
                .collect(Collectors.toList());
    }
}
