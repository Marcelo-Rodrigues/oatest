import { TestBed, inject } from '@angular/core/testing';

import { HttpAutenticadoService } from './http-autenticado.service';

describe('HttpAutenticadoService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HttpAutenticadoService]
    });
  });

  it('should be created', inject([HttpAutenticadoService], (service: HttpAutenticadoService) => {
    expect(service).toBeTruthy();
  }));
});
