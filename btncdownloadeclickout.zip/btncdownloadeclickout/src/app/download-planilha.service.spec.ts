import { TestBed, inject } from '@angular/core/testing';

import { DownloadPlanilhaService } from './download-planilha.service';

describe('DownloadPlanilhaService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DownloadPlanilhaService]
    });
  });

  it('should be created', inject([DownloadPlanilhaService], (service: DownloadPlanilhaService) => {
    expect(service).toBeTruthy();
  }));
});
