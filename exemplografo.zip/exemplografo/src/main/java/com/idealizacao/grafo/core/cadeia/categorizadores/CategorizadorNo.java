package com.idealizacao.grafo.core.cadeia.categorizadores;

import com.idealizacao.grafo.api.vo.cadeia.NoConsultadoVO;
import com.idealizacao.grafo.core.cadeia.no.No;

public interface CategorizadorNo {
    void setProximoCategorizador(CategorizadorNo proximoCategorizador);

    No categorizar(NoConsultadoVO noConsultado);
}
