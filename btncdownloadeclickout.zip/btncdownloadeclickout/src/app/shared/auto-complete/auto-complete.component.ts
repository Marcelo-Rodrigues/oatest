import { Component, OnInit, Input, Output, EventEmitter, HostListener, ElementRef } from '@angular/core';

@Component({
  selector: 'my-auto-complete',
  templateUrl: './auto-complete.component.html',
  styleUrls: ['./auto-complete.component.css']
})

export class AutoCompleteComponent implements OnInit {

  public query = '';
  public elementRef;

  @Input() filteredList: any[];
  @Output() onFilter = new EventEmitter<string>();

  ngOnInit(): void {
  }

  constructor(myElement: ElementRef) {
    this.elementRef = myElement;
  }

  filter() {
    this.onFilter.emit(this.query);
  }

  select(item) {
    this.query = item;
    this.filteredList = [];
  }

  clickedOut() {
    this.filteredList = [];
  }

}
