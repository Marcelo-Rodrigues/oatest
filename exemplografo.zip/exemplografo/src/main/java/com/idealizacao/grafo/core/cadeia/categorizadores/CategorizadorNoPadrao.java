package com.idealizacao.grafo.core.cadeia.categorizadores;

import com.idealizacao.grafo.api.vo.cadeia.NoConsultadoVO;
import com.idealizacao.grafo.core.cadeia.no.No;
import com.idealizacao.grafo.core.cadeia.no.TipoNo;

public class CategorizadorNoPadrao implements CategorizadorNo {
    private CategorizadorNo proximoCategorizador;

    @Override
    public void setProximoCategorizador(CategorizadorNo proximoCategorizador) {
        this.proximoCategorizador = proximoCategorizador;
    }

    @Override
    public No categorizar(NoConsultadoVO noConsultado) {
        return new No(noConsultado.getId(), noConsultado.getNome(), TipoNo.PESSOAFISICA);
    }
}
