import { Injectable, OnInit, HostListener } from '@angular/core';
import { HttpAutenticado } from './http-autenticado.service';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';

@Injectable()
export class AuthService {

  constructor(private http: HttpAutenticado) { }

  request() {

    this.http.get('http://localhost:8080/oatest/urlRoleA')
    .map(res => res.json())
      .subscribe(res => console.log('a: ' + JSON.stringify( res)),
      err => {
          console.log('erro: ' + err);
      });



    // .subscribe(res => console.log('a: ' + res),
    //   err => {
    //     if (err.status === 401) {
    //       console.log('autenticar: ' + err);

    //     } else {
    //       console.log('erro: ' + err);
    //     }
    //   });






    // this.http.get('http://localhost:8080/oatest/urlRoleC', options)
    //   .subscribe(res => console.log(res));
  }

}
