import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AutoCompleteComponent } from './shared/auto-complete/auto-complete.component';

import { FormsModule } from '@angular/forms';
import { BotaoDownloadComponent } from './shared/botao-download/botao-download.component';
import { DownloadPlanilhaService } from './download-planilha.service';
import { HttpModule } from '@angular/http';
import { ClickOutListenerDirective } from './shared/diretivas/click-out-listener.directive';

@NgModule({
  declarations: [
    AppComponent,
    AutoCompleteComponent,
    BotaoDownloadComponent,
    ClickOutListenerDirective
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule
  ],
  providers: [DownloadPlanilhaService],
  bootstrap: [AppComponent],
  exports: [ClickOutListenerDirective]
})
export class AppModule { }
