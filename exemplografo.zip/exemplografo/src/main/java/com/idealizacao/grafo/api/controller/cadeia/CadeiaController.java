package com.idealizacao.grafo.api.controller.cadeia;

import com.idealizacao.grafo.api.service.cadeia.CadeiaService;
import com.idealizacao.grafo.api.vo.cadeia.CadeiaProcessadaVO;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CadeiaController {
    private CadeiaService cadeiaService;

    public CadeiaController(CadeiaService cadeiaService) {
        this.cadeiaService = cadeiaService;
    }

    @GetMapping("/cadeia")
    public CadeiaProcessadaVO consultarCadeia() {
        return cadeiaService.consultarCadeia();
    }
}
