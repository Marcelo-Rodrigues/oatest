package com.idealizacao.grafo.core.cadeia.categorizadores;

import com.idealizacao.grafo.api.vo.cadeia.NoConsultadoVO;
import com.idealizacao.grafo.core.cadeia.no.No;
import com.idealizacao.grafo.core.cadeia.no.NoInstituicaoFinanceira;
import com.idealizacao.grafo.core.cadeia.no.TipoNo;

public class CategorizadorNoIF implements CategorizadorNo {
    private CategorizadorNo proximoCategorizador;

    @Override
    public void setProximoCategorizador(CategorizadorNo proximoCategorizador) {
        this.proximoCategorizador = proximoCategorizador;
    }

    @Override
    public No categorizar(NoConsultadoVO noConsultado) {
        if("00003".equals(noConsultado.getDocumento()) || "00004".equals(noConsultado.getDocumento())){
            return new NoInstituicaoFinanceira(noConsultado.getId(), noConsultado.getNome(), TipoNo.INSTITUICAOFINANCEIRA);
        } else {
            return proximoCategorizador.categorizar(noConsultado);
        }
    }
}
