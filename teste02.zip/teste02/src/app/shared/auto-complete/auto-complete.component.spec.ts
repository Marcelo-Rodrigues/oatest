import { async, fakeAsync, tick, ComponentFixture, TestBed } from '@angular/core/testing';
// https://stackoverflow.com/questions/39205036/testing-angular2-component-input-and-output
import { FormsModule } from '@angular/forms';
import { AutoCompleteComponent } from './auto-complete.component';
import { By } from '@angular/platform-browser';

function findElement(fixture, selector) {
  return fixture.debugElement.query(By.css(selector)).nativeElement;
}

describe('AutoCompleteComponent', () => {
  let component: AutoCompleteComponent;
  let fixture: ComponentFixture<AutoCompleteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutoCompleteComponent ],
      imports: [FormsModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoCompleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('deve ser criado', () => {
    expect(component).toBeTruthy();
  });

  it('deve atualizar o model', fakeAsync(() => {
    fixture = TestBed.createComponent(AutoCompleteComponent);
    fixture.detectChanges();
    tick();
    const input: HTMLInputElement = findElement(fixture, 'input');
    expect(input.value).toEqual('');
    input.value = 'item1';
    input.dispatchEvent(new Event('keyup'));
    expect(fixture.debugElement.componentInstance.query).toEqual('item1');
  }));

  it('deve propagar o evento', fakeAsync(() => {
    fixture = TestBed.createComponent(AutoCompleteComponent);
    fixture.detectChanges();
    tick();
    spyOn(fixture.debugElement.componentInstance, 'onFilter');
    const input: HTMLInputElement = findElement(fixture, 'input');
    input.value = 'item2';
    input.dispatchEvent(new Event('keyup'));
    expect(fixture.debugElement.componentInstance.onFilter).toHaveBeenCalledWith(
      jasmine.stringMatching('item2')
    );
  }));
});
