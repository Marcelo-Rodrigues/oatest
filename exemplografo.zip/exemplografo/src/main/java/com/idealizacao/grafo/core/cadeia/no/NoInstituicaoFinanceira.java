package com.idealizacao.grafo.core.cadeia.no;

public class NoInstituicaoFinanceira extends No {

    public NoInstituicaoFinanceira(int id, String descricao, TipoNo tipo) {
        super(id, descricao, tipo);
    }

    public String getGrupoIF() {
        // Executar serviço de/para inserido por construtor
        return id == 3 ? "Grupo IF 3": "Grupo IF 1";
    }
}
