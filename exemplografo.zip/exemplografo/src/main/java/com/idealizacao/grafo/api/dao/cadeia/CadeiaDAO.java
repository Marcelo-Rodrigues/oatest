package com.idealizacao.grafo.api.dao.cadeia;

import com.idealizacao.grafo.api.vo.cadeia.CadeiaConsultadaVO;
import com.idealizacao.grafo.api.vo.cadeia.NoConsultadoVO;
import org.springframework.stereotype.Service;

import java.util.Arrays;

@Service
public class CadeiaDAO {
    public CadeiaConsultadaVO consultarCadeia() {
        CadeiaConsultadaVO cadeiaConsultada = new CadeiaConsultadaVO(criarAncora());
        cadeiaConsultada.addRelacionados(
                Arrays.asList(
                        criarRelacionado(2, "A2"),
                        criarRelacionado(3, "B1"),
                        criarRelacionado(4, "C1"),
                        criarRelacionado(5, "C"),
                        criarRelacionado(6, "Z")
                )
        );
        return cadeiaConsultada;
    }

    private NoConsultadoVO criarAncora() {
        NoConsultadoVO noConsultado =  new NoConsultadoVO();
        noConsultado.setId(1);
        noConsultado.setNome("ancora");
        noConsultado.setRating("AAA");
        noConsultado.setDocumento("00001");
        return noConsultado;
    }

    private NoConsultadoVO criarRelacionado(int id, String rating) {
        NoConsultadoVO noConsultado =  new NoConsultadoVO();
        noConsultado.setId(id);
        noConsultado.setNome("relacionado"+(id-1));
        noConsultado.setRating(rating);
        noConsultado.setDocumento("0000" + id);
        return noConsultado;
    }
}
