package com.idealizacao.grafo.core.cadeia.no;

public class No {
    int id;
    String descricao;
    TipoNo tipo;

    public No(int id, String descricao, TipoNo tipo) {
        this.id = id;
        this.descricao = descricao;
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }
    public TipoNo getTipo() {
        return tipo;
    }

    public String getDescricao() {
        return descricao;
    }
    public String getCampoCalculado() {
        return "Funciona";
    }
}
